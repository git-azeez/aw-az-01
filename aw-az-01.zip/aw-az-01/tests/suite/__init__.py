# ClearLedger verifier test suite.
