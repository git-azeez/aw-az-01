resource "aws_cognito_user_pool" "main" {
  name = "${local.prefix}-users"
  tags = merge(local.tags, { Name = "${local.prefix}-users" })
}

resource "aws_cognito_resource_server" "main" {
  identifier   = "clearledger"
  name         = "${local.prefix}-clearledger"
  user_pool_id = aws_cognito_user_pool.main.id

  scope {
    scope_name        = "read"
    scope_description = "Read settlement projections and ledgers"
  }
  scope {
    scope_name        = "write"
    scope_description = "Initiate settlements and append ledger entries"
  }
  scope {
    scope_name        = "admin"
    scope_description = "Administrative projection rebuilds"
  }
}

locals {
  cognito_clients = toset(["read", "write", "admin"])
}

resource "aws_cognito_user_pool_client" "this" {
  for_each     = local.cognito_clients
  name         = "${local.prefix}-${each.key}"
  user_pool_id = aws_cognito_user_pool.main.id

  generate_secret                      = true
  allowed_oauth_flows_user_pool_client = true
  allowed_oauth_flows                  = ["client_credentials"]
  allowed_oauth_scopes                 = ["clearledger/${each.key}"]
  supported_identity_providers         = ["COGNITO"]

  depends_on = [aws_cognito_resource_server.main]
}

locals {
  issuer_url = "${local.endpoint}/${aws_cognito_user_pool.main.id}"
  jwks_url   = "${local.endpoint}/${aws_cognito_user_pool.main.id}/.well-known/jwks.json"
  auth_audiences = join(",", [
    aws_cognito_user_pool_client.this["read"].id,
    aws_cognito_user_pool_client.this["write"].id,
    aws_cognito_user_pool_client.this["admin"].id,
  ])
}
